# fujitsu
Fujitsu Japanese Guide
