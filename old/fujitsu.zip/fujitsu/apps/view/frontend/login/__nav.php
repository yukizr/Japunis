<div class="">
  <nav class="top-bar" data-topbar role="navigation">
    <ul class="title-area">
      <li class="name">
        <?php $logo = "logo.png"; ?>
        <a href="<?php echo base_url("home"); ?>"><img style="height:40px;margin:2px;" src="<?php echo base_url("assets/img/").$logo ?>" alt="Fujitsu Guide to Japanese" /></a>
      </li>

    </ul>
  </nav>
</div>

<!--//start of container//-->
<div class="container" style="padding-top:0em;">
