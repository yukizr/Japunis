<!--//contain row after container//-->
  <div class="row">
		<!--//container main //-->
    <!--//container main //-->
    <div class="large-12 columns">
      <h2 class="ttfos">Home</h2>
		  <hr />
		</div>


			<!--//content//-->
      <div class="small-12 medium-12 large-12 columns">
        	<div class="small-12 medium-6 large-6 align-center utama column">
        		<div class="card card-product-hover">
        			<img src="assets/img/blue_bw_web.jpg" alt="sweet foundation shirt">
        			<div class="card-product-hover-icons">
        			<a href="#"><i class="fa fa-shopping-cart"></i></a>
        			<a href="#"><i class="fa fa-star-o"></i></a>
        			<a href="#"><i class="fa fa-share-alt"></i></a>
        			</div>
        			<div class="card-product-hover-details">
        			<h3 class="card-product-hover-title">Legacy Foundation Tee</h3>
        			<span class="card-product-hover-price">$15.00</span>
        			</div>
        		</div>
        	</div>
        	<div class="small-12 medium-6 large-6 align-center utama column">
        		<div class="card card-product-hover">
        		<img src="assets/img/blue_bw_web.jpg" alt="picture of admin dashboard">
        		<div class="card-product-hover-icons">
        		<a href="#"><i class="fa fa-shopping-cart"></i></a>
        		<a href="#"><i class="fa fa-star-o"></i></a>
        		<a href="#"><i class="fa fa-share-alt"></i></a>
        		</div>
        		<div class="card-product-hover-details">
        		<h3 class="card-product-hover-title">Foundation Dashboard Theme</h3>
        		<span class="card-product-hover-price">$24.00</span>
        		</div>
        		</div>
        	</div>
        	<div class="small-12 medium-6 large-6 align-center utama column">
        		<div class="card card-product-hover">
        		<img src="assets/img/blue_bw_web.jpg" alt="picture of admin dashboard">
        		<div class="card-product-hover-icons">
        		<a href="#"><i class="fa fa-shopping-cart"></i></a>
        		<a href="#"><i class="fa fa-star-o"></i></a>
        		<a href="#"><i class="fa fa-share-alt"></i></a>
        		</div>
        		<div class="card-product-hover-details">
        		<h3 class="card-product-hover-title">Foundation UI Kit</h3>
        		<span class="card-product-hover-price">$11.00</span>
        		</div>
        		</div>
        	</div>
      </div>
			<div class="row">&nbsp;</div>
    </div>
  </div>
<!--//contain row after container//-->
