
			<div class="row">
				<!--paragraf 1-->
				<div class="large-12">
					<hr />
					&copy; <?php echo date("Y"); ?>
				</div>
			</div>
			<div class="row">&nbsp;</div>
    </div>
  </div>
<!--//contain row after container//-->