</div>
<!--//end of container//-->
<script src="<?php echo base_url('assets/js/vendor/jquery.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/foundation.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/vendor/jquery.dataTables.js'); ?>"></script>
<!--<script src="js/foundation/foundation.topbar.js"></script>//-->
<script>
</script>
