<!--//contain row after container//-->
  <div class="row">
		<!--//container main //-->
    <div class="large-12 columns">
			<!--//title//-->
			<div class="row">
				<div class="large-12 columns">
					<h2 class="ttfos">Materi</h2>
					<hr />
				</div>
			</div>
			<!--//content//-->
			<div class="row">
				<!--paragraf 1-->

				<div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("admin/pelajaran"); ?>" class="button expand disabled ttfos">Pelajaran</a>
					<!-- <div align="center">Materi 1 - 8</div><br> -->
				</div>
				<div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("barang_warna"); ?>" class="button expand disabled ttfos">Kuis</a>
					<!-- <div align="center">Latihan</div> -->
				</div>
				<div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("barang_warna"); ?>" class="button expand disabled ttfos">Abjad</a>
					<!-- <div align="center">Hiragana & Katakana</div> -->
				</div>
				<div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("log"); ?>" class="button expand disabled ttfos">Angka</a>
					<!-- <div align="center">1 - 100</div> -->
				</div>
        <div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("barang"); ?>" class="button expand disabled ttfos">Tanggal</a>
					<!-- <div align="center">Hari & Bulan</div> -->
				</div>
				<div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("barang_warna"); ?>" class="button expand disabled ttfos">Tata Bahasa</a>
					<!-- <div align="center">Tanya, Sifat, & Keterangan</div> -->
				</div>
				<div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("log"); ?>" class="button expand disabled ttfos">Kata & Ungkapan</a>
					<!-- <div align="center">Ragam Istilah</div> -->
				</div>
				<div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("log"); ?>" class="button expand disabled ttfos">Silabus</a>
					<!-- <div align="center">Ikhtisar Pelajaran</div> -->
				</div>
				<div class="small-12 medium-12 large-4 columns">
				</div>

			</div>
			<div class="row">&nbsp;</div>
      <!--//title//-->
			<div class="row">
				<div class="large-12 columns">
					<h2 class="ttfos">Manajemen</h2>
					<hr />
				</div>
			</div>
      <!--//content//-->
			<div class="row">
				<div class="small-12 medium-12 large-4 columns">
					<a href="<?php echo base_url("barang"); ?>" class="button expand disabled ttfos">Pengguna</a>
				</div>
      </div>

    </div>
  </div>
<!--//contain row after container//-->
