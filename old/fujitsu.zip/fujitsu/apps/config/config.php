<?php
$site = "http://localhost/fujitsu/";
$sene_method = "PATH_INFO";//REQUEST_URI,PATH_INFO,ORIG_PATH_INFO,
?>
