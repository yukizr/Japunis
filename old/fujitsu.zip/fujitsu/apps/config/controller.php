<?php
$default_controller='home';
$notfound_controller='notfound';

?>