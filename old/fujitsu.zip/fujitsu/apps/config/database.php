<?php
$db['host']  = "localhost";
$db['user']  = "root";
$db['pass']  = "";
$db['name']  = "fujitsu";
$db['engine']= "mysqli"; //available mysql,mysqli,pdo
$db['port']="3306";
?>
