<?php
$saltkey = 'odpasinaso220)*';
?>
